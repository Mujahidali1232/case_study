import * as React from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  Drawer,
  List,
  ListItemButton,
  ListItemText,
  Container,
  useScrollTrigger,
  Divider,
  IconButton,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "Kitchens", href: "#kitchens" },
  { label: "Wardrobes", href: "#wardrobes" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [open, setOpen] = React.useState(false);
  const trigger = useScrollTrigger({ disableHysteresis: true, threshold: 10 });
  const [activeHash, setActiveHash] = React.useState<string>(
    typeof window !== "undefined" ? window.location.hash : "#home"
  );

  // Close drawer with Esc and trap focus handled by MUI; also update active link on hash change
  React.useEffect(() => {
    const onHashChange = () => setActiveHash(window.location.hash || "#home");
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  // Optional: highlight on scroll if sections exist
  React.useEffect(() => {
    const sections = navLinks
      .map((l) => document.querySelector<HTMLElement>(l.href))
      .filter(Boolean) as HTMLElement[];

    if (!sections.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target?.id) setActiveHash(`#${visible.target.id}`);
      },
      { rootMargin: "-30% 0px -60% 0px", threshold: [0, 0.25, 0.5, 0.75, 1] }
    );

    sections.forEach((sec) => observer.observe(sec));
    return () => observer.disconnect();
  }, []);

  const LinkButton = ({ label, href }: { label: string; href: string }) => (
    <Button
      key={label}
      href={href}
      aria-current={activeHash === href ? "page" : undefined}
      sx={{
        color: "text.primary",
        fontWeight: 500,
        fontSize: { md: "0.95rem", lg: "1rem" },
        position: "relative",
        px: 1,
        "&::after": {
          content: '""',
          position: "absolute",
          bottom: 0,
          left: 0,
          width: activeHash === href ? "100%" : 0,
          height: 2,
          bgcolor: "primary.main",
          transition: "width .25s ease",
        },
        "&:hover::after": { width: "100%" },
      }}
    >
      {label}
    </Button>
  );

  return (
    <AppBar
      component="nav"
      position="sticky"
      elevation={trigger ? 4 : 0}
      sx={{
        bgcolor: trigger ? "rgba(255,255,255,0.95)" : "transparent",
        color: "text.primary",
        backdropFilter: trigger ? "blur(12px)" : "none",
        transition: "all 0.3s ease",
      }}
    >
      {/* Skip to content for a11y */}
      <Box
        component="a"
        href="#main"
        sx={{
          position: "absolute",
          left: -1000,
          top: 0,
          "&:focus": {
            left: 8,
            top: 8,
            bgcolor: "primary.main",
            color: "black",
            px: 1.5,
            py: 0.5,
            borderRadius: 1,
            zIndex: 1200,
          },
        }}
      >
        Skip to content
      </Box>

      <Container maxWidth="xl">
        <Toolbar disableGutters sx={{ minHeight: { xs: 64, md: 72 }, display: "flex", gap: 2 }}>
          {/* LOGO */}
          <Typography
            variant="h6"
            sx={{
              fontWeight: 800,
              letterSpacing: 0.5,
              flexGrow: { xs: 1, md: 0 },
              fontSize: { xs: 18, md: 20 },
            }}
          >
            Kitchen<span style={{ color: "#EDA735" }}>Design</span>
          </Typography>

          {/* DESKTOP LINKS */}
          <Box
            sx={{
              display: { xs: "none", md: "flex" },
              gap: { md: 2, lg: 3 },
              ml: "auto",
              alignItems: "center",
            }}
          >
            {navLinks.map((link) => (
              <LinkButton key={link.label} label={link.label} href={link.href} />
            ))}
            <Button
              variant="contained"
              sx={{
                bgcolor: "primary.main",
                color: "black",
                fontWeight: 600,
                px: { md: 2.25, lg: 2.5 },
                py: 1,
                borderRadius: "20px",
                "&:hover": { bgcolor: "primary.dark" },
              }}
            >
              Get Quote
            </Button>
          </Box>

          {/* MOBILE MENU ICON */}
          <IconButton
            edge="end"
            aria-label="Open menu"
            aria-haspopup="true"
            aria-controls="mobile-menu"
            onClick={() => setOpen(true)}
            sx={{ ml: "auto", display: { xs: "flex", md: "none" } }}
          >
            <MenuIcon />
          </IconButton>

          {/* MOBILE DRAWER */}
          <Drawer
            id="mobile-menu"
            anchor="right"
            open={open}
            onClose={() => setOpen(false)}
            PaperProps={{ sx: { width: 280, p: 2 } }}
            ModalProps={{ keepMounted: true }}
          >
            <Typography variant="h6" sx={{ fontWeight: 800, mb: 1 }}>
              Kitchen<span style={{ color: "#EDA735" }}>Design</span>
            </Typography>
            <Divider sx={{ mb: 1.5 }} />
            <List role="menu" aria-label="Main navigation">
              {navLinks.map((l) => (
                <ListItemButton
                  key={l.label}
                  component="a"
                  href={l.href}
                  selected={activeHash === l.href}
                  role="menuitem"
                  onClick={() => setOpen(false)}
                >
                  <ListItemText
                    primary={l.label}
                    primaryTypographyProps={{ fontWeight: 500 }}
                  />
                </ListItemButton>
              ))}
            </List>
            <Button
              fullWidth
              variant="contained"
              sx={{
                mt: 2,
                bgcolor: "primary.main",
                color: "black",
                fontWeight: 600,
                borderRadius: "20px",
                "&:hover": { bgcolor: "primary.dark" },
              }}
              onClick={() => setOpen(false)}
            >
              Get Quote
            </Button>
          </Drawer>
        </Toolbar>
      </Container>
    </AppBar>
  );
}
