// src/components/Hero.tsx
import React from "react";
import { Box, Button, Stack, Typography } from "@mui/material";
import heroImg from "../assets/profle.png";

const AMBER = "#D9A244";
const DARK = "#2F3B57";

const Hero: React.FC = () => {
  return (
    <Box
      component="section"
      id="kitchens"
      sx={{
        position: "relative",
        width: "100%",
        maxWidth: 1920,
        mx: "auto",
        // Responsive height for the whole hero section
        height: { xs: 640, sm: 700, md: 780, lg: 840, xl: 880 },
        overflow: "visible",
        scrollMarginTop: { xs: "72px", md: "88px" },
        px: { xs: 2, sm: 3 },
      }}
    >
      {/* Yellow card (responsive position & size) */}
      <Box
        sx={{
          position: "absolute",
          // position tuned to keep composition similar across sizes
          top: { xs: 48, sm: 64, md: 72, lg: 86 },
          left: { xs: "6%", sm: "8%", md: "30%", lg: "31%" },
          width: { xs: "88%", sm: "84%", md: "60%", lg: "60%" },
          maxWidth: { md: 1154 },
          height: { xs: 420, sm: 480, md: 640, lg: 728 },
          bgcolor: AMBER,
          borderRadius: 3.75, // 30px
          opacity: 1,
          boxShadow: { xs: "0 12px 24px rgba(0,0,0,.12)", md: "0 24px 48px rgba(0,0,0,.18)" },
        }}
      >
        {/* Content block — centered text + button */}
        <Box
          sx={{
            position: "absolute",
            inset: 0,
            p: { xs: 3, sm: 4, md: 6 },
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
          }}
        >
          <Stack spacing={{ xs: 2.25, sm: 2.75, md: 3 }} sx={{ maxWidth: { xs: 640, md: 760 }, alignItems: "center" }}>
            <Typography
              component="h1"
              sx={{
                fontWeight: 800,
                fontSize: { xs: 28, sm: 34, md: 42, lg: 44 },
                lineHeight: 1.15,
                color: "#0B0B0C",
              }}
            >
              We are Expert in Kitchen Transformations
            </Typography>

            <Typography
              sx={{
                color: "#0B0B0C",
                opacity: 0.95,
                fontSize: { xs: 14, sm: 15, md: 16 },
                lineHeight: 1.55,
              }}
            >
              Kitchen Design is a premium kitchen interior and renovation company based in Dubai, offering tailored
              solutions for modern, classic, and luxury kitchen spaces. Their mission is to transform ordinary kitchens
              into functional, elegant, and personalized environments. From 3D visual planning to modular installations
              and full-scale renovations, the brand focuses on quality craftsmanship, innovative layouts, and customer
              satisfaction.
            </Typography>

            <Button
              variant="contained"
              sx={{
                bgcolor: DARK,
                color: "#fff",
                borderRadius: "10px",
                textTransform: "none",
                fontWeight: 700,
                px: { xs: 2.25, md: 2.5 },
                py: { xs: 1, md: 1.25 },
                boxShadow: "none",
                "&:hover": { bgcolor: "#253149", boxShadow: "none" },
              }}
            >
              Read More
            </Button>
          </Stack>
        </Box>
      </Box>

      {/* Image card (responsive) */}
      <Box
        sx={{
          position: "absolute",
          // Places image to the left and slightly lower than the yellow card
          top: { xs: 210, sm: 220, md: 220, lg: 203 },
          left: { xs: "5%", sm: "6%", md: 176 },
          width: { xs: "70%", sm: "62%", md: 662 },
          height: { xs: 280, sm: 360, md: 486 },
          borderRadius: 3.75,
          overflow: "hidden",
          opacity: 1,
          boxShadow: { xs: "0 16px 32px rgba(0,0,0,.18)", md: "0 30px 60px rgba(0,0,0,.25)" },
          bgcolor: "#0f172a",
        }}
      >
        <Box
          component="img"
          src={heroImg}
          alt="Kitchen"
          sx={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
        />
        {/* Optional overlay slot */}
        <Box sx={{ position: "absolute", inset: 0, p: 2 }} />
      </Box>

      {/* Mobile stacking helper: when very small, let image stack below */}
      <Box
        sx={{
          display: { xs: "block", md: "none" },
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: 24,
          background: "linear-gradient(180deg, rgba(0,0,0,0) 0%, rgba(0,0,0,.02) 100%)",
        }}
      />
    </Box>
  );
};

export default Hero;
